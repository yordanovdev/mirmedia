exports.id = 371;
exports.ids = [371];
exports.modules = {

/***/ 194:
/***/ ((module) => {

// Exports
module.exports = {
	"create": "Create_create__XPe3a",
	"segment": "Create_segment__phM9c",
	"input": "Create_input__a19x_",
	"preview": "Create_preview__Kw7Rm",
	"btn": "Create_btn__1___o"
};


/***/ }),

/***/ 1553:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tinymce_tinymce_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6451);
/* harmony import */ var _tinymce_tinymce_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tinymce_tinymce_react__WEBPACK_IMPORTED_MODULE_2__);



const CustomEditor = ({ initialValue , editorRef  })=>{
    const key = "p1florohkpaeibgkoubtlmh6tcjm9ffp1ovdxgfwiox7vab2";
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tinymce_tinymce_react__WEBPACK_IMPORTED_MODULE_2__.Editor, {
        onInit: (evt, editor)=>editorRef.current = editor,
        initialValue: initialValue,
        id: "hello",
        apiKey: key,
        tinymceScriptSrc: "/tinymce/tinymce.min.js",
        init: {
            height: 500,
            menubar: false,
            plugins: [
                "advlist autolink lists link image charmap print preview anchor",
                "searchreplace visualblocks code fullscreen",
                "insertdatetime media table paste code help wordcount", 
            ],
            toolbar: "undo redo | formatselect | " + "bold italic backcolor forecolor | alignleft aligncenter " + "alignright alignjustify | bullist numlist outdent indent | " + "removeformat | help",
            content_style: "body { font-family:Helvetica,Arial,sans-serif; font-size:14px }"
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomEditor);


/***/ }),

/***/ 3828:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ useAuth)
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);

const useAuth = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
    const checkAuth = ()=>{
        if (localStorage.accessToken) {
            return;
        } else {
            router.push("/login");
        }
    };
    const isAuth = ()=>{
        return localStorage.accessToken;
    };
    return {
        checkAuth,
        isAuth
    };
};



/***/ }),

/***/ 6292:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var https__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5687);
/* harmony import */ var https__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(https__WEBPACK_IMPORTED_MODULE_1__);


const http = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
    baseURL: "https://localhost:44311/",
    httpsAgent: new (https__WEBPACK_IMPORTED_MODULE_1___default().Agent)({
        rejectUnauthorized: false
    })
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (http);


/***/ })

};
;