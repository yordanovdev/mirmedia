(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 7656:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "Footer_main__LZSM_",
	"logoContainer": "Footer_logoContainer__3N_Iw",
	"social-links": "Footer_social-links__IxXi3",
	"quoteContainer": "Footer_quoteContainer__sF_iw",
	"rightSideContainer": "Footer_rightSideContainer__1dBzV"
};


/***/ }),

/***/ 9634:
/***/ ((module) => {

// Exports
module.exports = {

};


/***/ }),

/***/ 9812:
/***/ ((module) => {

// Exports
module.exports = {
	"navbar": "NavBar_navbar__JWJL8",
	"leftSide": "NavBar_leftSide__D7IPo",
	"navLogo": "NavBar_navLogo__7AlF8",
	"rightSide": "NavBar_rightSide__aKJNs",
	"navText": "NavBar_navText__IJ31a",
	"links": "NavBar_links__nRhln",
	"actions": "NavBar_actions__FaeWR",
	"volunteerBtn": "NavBar_volunteerBtn__e1wQY",
	"openBtn": "NavBar_openBtn__43k85",
	"closeBtn": "NavBar_closeBtn__Suy2g",
	"open": "NavBar_open__FZOzy",
	"createPost": "NavBar_createPost__3npBD",
	"logoutBtn": "NavBar_logoutBtn__Fqpfw"
};


/***/ }),

/***/ 8656:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./styles/MainLayout.module.css
var MainLayout_module = __webpack_require__(9634);
var MainLayout_module_default = /*#__PURE__*/__webpack_require__.n(MainLayout_module);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./styles/Footer.module.css
var Footer_module = __webpack_require__(7656);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
;// CONCATENATED MODULE: ./components/Footer/Footer.js




const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Footer_module_default()).main,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Footer_module_default()).quoteContainer,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        children: "Присъедини се!"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Стани част от първата независима ученическа медия в България!"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Footer_module_default()).logoContainer,
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: "/images/logo.png",
                    alt: "logo"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Footer_module_default()).rightSideContainer,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Footer_module_default())["social-links"],
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "#",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fab fa-facebook-f"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://www.youtube.com/channel/UC4Nh0CvW4V_LMpzzw3267rA",
                                target: "_blank",
                                rel: "noreferrer",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fab fa-youtube"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://www.instagram.com/mirmedia.bg/",
                                target: "_blank",
                                rel: "noreferrer",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fab fa-instagram"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/join-us",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (Footer_module_default()).rightSideSecondElement,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                children: "Подай сигнал"
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Footer_Footer = (Footer);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./styles/NavBar.module.css
var NavBar_module = __webpack_require__(9812);
var NavBar_module_default = /*#__PURE__*/__webpack_require__.n(NavBar_module);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./services/auth/useAuth.js
var useAuth = __webpack_require__(3828);
;// CONCATENATED MODULE: ./components/NavBar/NavBar.js







const NavBar = ()=>{
    const { 0: open , 1: setOpen  } = (0,external_react_.useState)(false);
    const { 0: authenticated , 1: setAuthenticated  } = (0,external_react_.useState)(false);
    const router = (0,router_.useRouter)();
    const auth = (0,useAuth/* useAuth */.a)();
    (0,external_react_.useEffect)(()=>{
        setAuthenticated(auth.isAuth());
        setOpen(false);
    }, [
        router.asPath
    ]);
    const handleLogout = ()=>{
        localStorage.removeItem("accessToken");
        window.location.reload();
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (NavBar_module_default()).navbar,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (NavBar_module_default()).leftSide,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (NavBar_module_default()).navLogo,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/images/logo.png",
                                alt: "logo image",
                                className: (NavBar_module_default()).logo,
                                width: 70,
                                height: 70
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (NavBar_module_default()).navText,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                children: "MIRMEDIA.BG"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (NavBar_module_default()).rightSide,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `${(NavBar_module_default()).links} ${open && (NavBar_module_default()).open}`,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: ()=>setOpen(false),
                                className: (NavBar_module_default()).closeBtn,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "fa fa-close"
                                })
                            }),
                            links.map((link)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: link.to,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (NavBar_module_default()).link,
                                        children: link.text
                                    })
                                }, link.text)),
                            authenticated && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/signals/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: (NavBar_module_default()).link,
                                        children: "Signals"
                                    })
                                })
                            })
                        ]
                    }),
                    authenticated && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (NavBar_module_default()).actions,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/posts/create",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: `${(NavBar_module_default()).volunteerBtn} ${(NavBar_module_default()).createPost}`,
                                    style: {
                                        backgroundColor: "purple",
                                        marginRight: "15px"
                                    },
                                    children: "Create Post"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: `${(NavBar_module_default()).volunteerBtn} ${(NavBar_module_default()).logoutBtn}`,
                                onClick: handleLogout,
                                style: {
                                    backgroundColor: "blue"
                                },
                                children: "Logout"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/join-us",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (NavBar_module_default()).actions,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: (NavBar_module_default()).volunteerBtn,
                                children: "Подай Сигнал"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>setOpen(true),
                        className: (NavBar_module_default()).openBtn,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "fa fa-bars"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const NavBar_NavBar = (NavBar);
const links = [
    {
        text: "Начало",
        to: "/"
    },
    {
        text: "Блог",
        to: "/blog"
    },
    {
        text: "За нас",
        to: "/about-us"
    }, 
];

;// CONCATENATED MODULE: ./components/Layout/MainLayout.js





const MainLayout = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (MainLayout_module_default()).main,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(NavBar_NavBar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (MainLayout_module_default()).content,
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Footer_Footer, {})
        ]
    });
};
/* harmony default export */ const Layout_MainLayout = (MainLayout);

// EXTERNAL MODULE: external "react-loader-spinner"
var external_react_loader_spinner_ = __webpack_require__(1223);
;// CONCATENATED MODULE: ./components/Loading/Loading.js




function Loading() {
    const router = (0,router_.useRouter)();
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        const handleStart = (url)=>url !== router.asPath && setLoading(true);
        const handleComplete = (url)=>{
            if (url !== router.asPath) {
                setTimeout(()=>{
                    setLoading(false);
                }, 300);
            } else {
                setLoading(false);
            }
        };
        router.events.on("routeChangeStart", handleStart);
        router.events.on("routeChangeComplete", handleComplete);
        router.events.on("routeChangeError", handleComplete);
        return ()=>{
            router.events.off("routeChangeStart", handleStart);
            router.events.off("routeChangeComplete", handleComplete);
            router.events.off("routeChangeError", handleComplete);
        };
    }, [
        router.asPath
    ]);
    return loading ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "spinner-wrapper",
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_loader_spinner_.RotatingLines, {
            strokeColor: "purple",
            strokeWidth: "5",
            animationDuration: "0.75",
            width: "96",
            visible: loading
        })
    }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
}
/* harmony default export */ const Loading_Loading = (Loading);

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./components/RenderHead/RenderHead.js


const RenderHead = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("title", {
                children: "Mirmedia"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:image",
                content: "https://mirmedia.vercel.app/images/logo.png"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:title",
                content: "Mir Media"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:description",
                content: "Occaecat sint culpa reprehenderit sint cupidatat duis. Aliqua reprehenderit ullamco ipsum amet nisi in occaecat mollit."
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:type",
                content: "article"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                name: "twitter:card",
                content: "summary_large_image"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                name: "twitter:title",
                content: "Mir Media"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                name: "twitter:description",
                content: "Culpa magna cillum do consequat occaecat. Occaecat et excepteur officia non consequat eu non culpa deserunt ipsum consequat."
            })
        ]
    });
};
/* harmony default export */ const RenderHead_RenderHead = (RenderHead);

// EXTERNAL MODULE: ./node_modules/primereact/resources/themes/lara-light-indigo/theme.css
var theme = __webpack_require__(9951);
// EXTERNAL MODULE: ./node_modules/primereact/resources/primereact.min.css
var primereact_min = __webpack_require__(5626);
;// CONCATENATED MODULE: ./pages/_app.js










function App({ Component , pageProps  }) {
    const router = (0,router_.useRouter)();
    const Layout = Component.Layout ?? Layout_MainLayout;
    (0,external_react_.useEffect)(()=>{
        if (window) {
            window.scrollTo(0, 0);
        }
    }, [
        router.asPath
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Layout, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(RenderHead_RenderHead, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Loading_Loading, {})
        ]
    });
}
/* harmony default export */ const _app = (App);


/***/ }),

/***/ 3828:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ useAuth)
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);

const useAuth = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
    const checkAuth = ()=>{
        if (localStorage.accessToken) {
            return;
        } else {
            router.push("/login");
        }
    };
    const isAuth = ()=>{
        return localStorage.accessToken;
    };
    return {
        checkAuth,
        isAuth
    };
};



/***/ }),

/***/ 5626:
/***/ (() => {



/***/ }),

/***/ 9951:
/***/ (() => {



/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 1223:
/***/ ((module) => {

"use strict";
module.exports = require("react-loader-spinner");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [311,952,910,664,675], () => (__webpack_exec__(8656)));
module.exports = __webpack_exports__;

})();