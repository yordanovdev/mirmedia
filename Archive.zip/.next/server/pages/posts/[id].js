(() => {
var exports = {};
exports.id = 646;
exports.ids = [646];
exports.modules = {

/***/ 5222:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "PostDetails_main__XH46f",
	"post": "PostDetails_post__s3CqG",
	"creationTime": "PostDetails_creationTime__5fgYG",
	"title": "PostDetails_title__ByeQz",
	"image": "PostDetails_image__Ttq6r",
	"editBtn": "PostDetails_editBtn__ilfw3",
	"hr": "PostDetails_hr__dSlyZ"
};


/***/ }),

/***/ 3812:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _id_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./services/http/httpService.js
var httpService = __webpack_require__(6292);
;// CONCATENATED MODULE: external "react-quilljs"
const external_react_quilljs_namespaceObject = require("react-quilljs");
// EXTERNAL MODULE: ./styles/PostDetails.module.css
var PostDetails_module = __webpack_require__(5222);
var PostDetails_module_default = /*#__PURE__*/__webpack_require__.n(PostDetails_module);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./services/auth/useAuth.js
var useAuth = __webpack_require__(3828);
;// CONCATENATED MODULE: ./pages/posts/[id]/index.js









const PostDetails = ({ data  })=>{
    const { title , creationTime , content , imageUrl , id  } = data;
    const { 0: authenticated , 1: setAuthenticated  } = (0,external_react_.useState)(false);
    const { quill  } = (0,external_react_quilljs_namespaceObject.useQuill)();
    const auth = (0,useAuth/* useAuth */.a)();
    const { 0: text , 1: setText  } = (0,external_react_.useState)(content);
    const router = (0,router_.useRouter)();
    (0,external_react_.useEffect)(()=>{
        setAuthenticated(auth.isAuth());
        if (quill) {
            quill.clipboard.dangerouslyPasteHTML(text);
            quill.on("text-change", ()=>{
                setText(quill.root.innerHTML); // Get text only
            });
        }
    }, [
        quill
    ]);
    const deletePost = ()=>{
        var input = confirm("Are you sure you want to remove this post? ");
        if (input) {
            httpService/* default.delete */.Z["delete"]("api/services/app/Posts/Delete", {
                params: {
                    id
                }
            }).then(()=>{
                router.back();
            }).catch(()=>{
                alert("There was an error with the request");
            });
        } else {}
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (PostDetails_module_default()).post,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(RenderHeadPost, {
                data: data
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (PostDetails_module_default()).main,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: imageUrl ?? "",
                        alt: title,
                        className: (PostDetails_module_default()).image
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: (PostDetails_module_default()).title,
                        children: title
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: (PostDetails_module_default()).creationTime,
                        children: [
                            "Published on",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: new Date(creationTime).toLocaleDateString()
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                        className: (PostDetails_module_default()).hr
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "ql-editor",
                        dangerouslySetInnerHTML: {
                            __html: text
                        }
                    }),
                    authenticated && /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_default()).Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("hr", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: router.asPath + "/edit",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: (PostDetails_module_default()).editBtn,
                                    children: "Edit"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                style: {
                                    backgroundColor: "red"
                                },
                                className: (PostDetails_module_default()).editBtn,
                                onClick: ()=>deletePost(),
                                children: "Delete"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
const RenderHeadPost = ({ data  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("title", {
                children: data.title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:image",
                content: data.imageUrl ?? ""
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:image:secure_url",
                content: data.imageUrl ?? ""
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:image:type",
                content: "image/jpeg"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:image:width",
                content: "400"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:image:height",
                content: "300"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:image:alt",
                content: data.description
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:title",
                content: data.title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:description",
                content: data.description
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:type",
                content: "article"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                name: "twitter:card",
                content: "summary_large_image"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                name: "twitter:title",
                content: data.title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                name: "twitter:description",
                content: data.description
            })
        ]
    });
};
const getServerSideProps = async (context)=>{
    const { id  } = context.query;
    const result = await httpService/* default.get */.Z.get("api/services/app/Posts/Get", {
        params: {
            id
        }
    });
    const data = result.data;
    return {
        props: {
            data: data.result
        }
    };
};
/* harmony default export */ const _id_ = (PostDetails);


/***/ }),

/***/ 3828:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ useAuth)
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);

const useAuth = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
    const checkAuth = ()=>{
        if (localStorage.accessToken) {
            return;
        } else {
            router.push("/login");
        }
    };
    const isAuth = ()=>{
        return localStorage.accessToken;
    };
    return {
        checkAuth,
        isAuth
    };
};



/***/ }),

/***/ 6292:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var https__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5687);
/* harmony import */ var https__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(https__WEBPACK_IMPORTED_MODULE_1__);


const http = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
    baseURL: "https://localhost:44311/",
    httpsAgent: new (https__WEBPACK_IMPORTED_MODULE_1___default().Agent)({
        rejectUnauthorized: false
    })
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (http);


/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [311,952,910,664], () => (__webpack_exec__(3812)));
module.exports = __webpack_exports__;

})();