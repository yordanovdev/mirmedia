import React from "react";

const BlankLayout = ({ children }) => {
  return children;
};

export default BlankLayout;
